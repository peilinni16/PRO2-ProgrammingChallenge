var searchData=
[
  ['imp_5fcluster',['imp_cluster',['../class_cluster.html#a25c0220fbad15328b30df8f9cf0c845a',1,'Cluster']]],
  ['imprime_5farbol_5ffilogenetico',['imprime_arbol_filogenetico',['../class_cjt___clusters.html#a95262506a2fdc5455ce104fb84649ee9',1,'Cjt_Clusters']]],
  ['imprime_5fcjt_5fespecies',['imprime_cjt_especies',['../class_cjt___especies.html#a61b0168970e926d3a27faf3f31ad2869',1,'Cjt_Especies']]],
  ['imprime_5fclust_5fdistancias',['imprime_clust_distancias',['../class_cjt___clusters.html#a3f56a11d83d14d8dc58df32ea70163fa',1,'Cjt_Clusters']]],
  ['imprime_5fcluster',['imprime_cluster',['../class_cjt___clusters.html#a17f8056edf94da434c058b0a7758b93c',1,'Cjt_Clusters']]],
  ['inicializa_5fclusters',['inicializa_clusters',['../class_cjt___especies.html#ae599e4e30a1d77e435395b796f821e06',1,'Cjt_Especies']]]
];
