var searchData=
[
  ['busca_5fminimo',['busca_minimo',['../class_cjt___clusters.html#afc180c4e851b321837f6d2c173916e57',1,'Cjt_Clusters']]]
];
