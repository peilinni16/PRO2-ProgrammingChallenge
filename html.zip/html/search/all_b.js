var searchData=
[
  ['obtener_5fgen',['obtener_gen',['../class_cjt___especies.html#a4cc8f3f5c7f0eadbb19526bbc1ab10bc',1,'Cjt_Especies']]]
];
